public class Order 
{
	//attributes
	String wholeOrder;
  int space;
  int decimal;


	//Constructor
	public Order (String _customerOrder)
	{
		wholeOrder = _customerOrder;
	}
	
	//methods
  public String getComboNumber(){
    decimal = wholeOrder.indexOf(".");
    String comboNumber = wholeOrder.substring(0,decimal); 
  return comboNumber;
  }

  public String getFood(){
    space = wholeOrder.indexOf(" ");
    String foodPortion = wholeOrder.substring(space);
  return foodPortion;
  }
  
  public String toString(){
    return "Customer ordered number " + getComboNumber() + "\n" + "Your ordered " + getFood() + " which is combo #" + getComboNumber()+ "\n"; 
  }

}
// Complete the following methods:

//     getComboNumber() - returns an int of the combo number
//     getFood() - returns the food portion of the order
//     toString() - returns the string representation of the object. See sample output


// Sample Output 1:

// Enter whole order: 
// 6. 2 Tacos
// Customer ordered number 6
// You ordered 2 Tacos which is combo #6


// Sample Output 2:

// Enter whole order: 
// 10. Pizza
// Customer ordered number 10
// You ordered Pizza which is combo #10

