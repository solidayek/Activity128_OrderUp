import java.util.Scanner;

class Main 
{
	public static void main(String[] args) 
	{
    	// Create scanner object
      Scanner sc = new Scanner(System.in);

        // Display menu
        String menu = "1. Hamburger\n2. Cheeseburger\n3. Veggie Burger\n4. Nachos\n5. Hot Dog\n";
        menu +="6. 2 Tacos\n7. Burrito\n8. Ham Sandwich\n9. PB&J Sandwich\n10. Pizza\n";
        
        System.out.println(menu);
        
        // Get customer order
        System.out.println("Enter whole order: ");
        String customer1_WholeOrder = sc.nextLine();

        // Create Order object
        Order Customer1 = new Order(customer1_WholeOrder);

        // Print out what number the customer ordered
        System.out.println(Customer1.getComboNumber());
        System.out.println(Customer1.getFood());

        //Print out object
        System.out.println(Customer1.toString());
	}
}